package dao;

import java.util.ArrayList;

import dto.BuyListDTO;
import dto.DateDTO;
import dto.MovieDTO;
import dto.NoticeDTO;
import dto.SeatDTO;
import dto.TheaterDTO;
import dto.UserDTO;

//데이터베이스 접근
public interface UserDao {
	// 유저를 불러오기
	UserDTO selectUser(String key);

	// 유저를 추가하기
	void insertUser(UserDTO user);

	// 유저리스트
	ArrayList<UserDTO> selectUserList();

	// 공지사항 등록(db에서 공지사항 불러오기)
	void insertNotice(NoticeDTO notice);

	// 공지사항수정
	ArrayList<NoticeDTO> noticeChange();

	// 영화등록(db에서 영화정보 불러오기)
	void insertMovie(MovieDTO movie);
	
	// 영화리스트
	ArrayList<MovieDTO> movieList();

	// 상영관등록
	void insertTheater(TheaterDTO theater);

	// 상영관리스트
	ArrayList<TheaterDTO> theaterList();

	// 좌석등록
	void insertSeat(SeatDTO seat);
	
	// 좌석리스트
	ArrayList<SeatDTO> seatList();

	//날짜등록
	void dateRegister(DateDTO date);
	
	//날짜선택
	ArrayList<DateDTO> dateList();

	// 회원탈퇴(db에서 회원정보 불러오기)
	void deleteUser(String key);

	// 공지사항보기(db에서 정보 불러오기
	ArrayList<NoticeDTO> noticeView();

	// 비밀번호 수정(db에서 정보 불러오기)
	void pwChange(String key, String pw);

	// 핸드폰번호 수정(db에서 정보 불러오기)
	void phoneChange(String key, String phone);

	// 영화순위(db에서 영화정보 불러오기)
	void movieSort(Integer key, Integer rank);

	// 영화예매(db에서 정보 불러오기)

	// 예매취소
	void movieDrop(String key, int cal);

	// 결제(db에서 영화가격을 불러와서 영화가격*인원수)
	void insertPay(BuyListDTO buy);

	// 구매내역 출력(db에서 구매내역정보 불러오기)
	ArrayList<BuyListDTO> buyList();
	

}