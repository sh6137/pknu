package dao;

import java.io.IOException;
import java.util.ArrayList;

import File.DateFile;
import File.MovieFile;
import File.NoticeFile;
import File.TheaterFile;
import File.UserFile;
import dto.BuyListDTO;
import dto.Database;
import dto.DateDTO;
import dto.MovieDTO;
import dto.NoticeDTO;
import dto.SeatDTO;
import dto.TheaterDTO;
import dto.UserDTO;

//데이터베이스 접근
public class UserDaoImpl implements UserDao {
	public UserDaoImpl () {
//		System.out.println(Database.tb_user);
		if (Database.tb_user.isEmpty() == true) {
			UserFile temp = new UserFile();
			try {
				Database.tb_user = temp.UserFileOut();
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
		//영화
		if (Database.tb_movie.isEmpty() == true) {
			MovieFile temp = new MovieFile();
			try {
				Database.tb_movie = temp.MovieFileOut();
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
		if (Database.tb_notice.isEmpty() == true) {
			NoticeFile temp = new NoticeFile();
			try {
				Database.tb_notice = temp.NoticeFileOut();
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
		if (Database.tb_theater.isEmpty() == true) {
			TheaterFile temp = new TheaterFile();
			try {
				Database.tb_theater = temp.TheaterFileOut();
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
		//날짜
//		if (Database.tb_date.isEmpty() == true) {
//			DateFile temp = new DateFile();
//			try {
//				Database.tb_date = temp.DateFileOut();
//			} catch(IOException e) {
//				e.printStackTrace();
//			}
//		}
		UserDTO user = new UserDTO();
		Database.tb_user.add(user);
		user.setId("root");
		user.setPw("root");
		user.setName("관리자");
		user.setPhone("777");
	}

	// 유저불러오기
	@Override
	public UserDTO selectUser(String key) {
		for (int i = 0; i < Database.tb_user.size(); i++) {
			UserDTO user = Database.tb_user.get(i);

			if (user.getId().equals(key)) {
				return user;
			}
		}
		return null;
	}

	// 유저추가하기
	@Override
	public void insertUser(UserDTO user) {
		Database.tb_user.add(user);
	}

	// 유저리스트
	@Override
	public ArrayList<UserDTO> selectUserList() {
		return Database.tb_user;
	}

	// 유저삭제하기
	@Override
	public void deleteUser(String key) {
		for (int i = 0; i < Database.tb_user.size(); i++) {
			UserDTO user = Database.tb_user.get(i);

			if (key == user.getId()) {
				Database.tb_user.remove(i);
			}
		}
	}

	// 비밀번호 수정
	@Override
	public void pwChange(String key, String pw) {
		for (int i = 0; i < Database.tb_user.size(); i++) {
			UserDTO user = Database.tb_user.get(i);

			if (key == user.getId()) {
				Database.tb_user.get(i).setPw(pw);
			}
		}
	}

	// 핸드폰번호 수정
	@Override
	public void phoneChange(String key, String phone) {
		for (int i = 0; i < Database.tb_user.size(); i++) {
			UserDTO user = Database.tb_user.get(i);

			if (user.getId().equals(key)) {
				Database.tb_user.get(i).setPhone(phone);
			}
		
		}
	}

	// 공지사항 등록
	@Override
	public void insertNotice(NoticeDTO notice) {
		Database.tb_notice.add(notice);
	}

	// 영화 등록
	@Override
	public void insertMovie(MovieDTO movie) {
		Database.tb_movie.add(movie);

	}
	
	// 영화리스트
	@Override
	public ArrayList<MovieDTO> movieList() {
		return Database.tb_movie;
	}
	
	// 상영관등록
	@Override
	public void insertTheater(TheaterDTO theater) {
		Database.tb_theater.add(theater);
	}

	//상영관 리스트
	@Override
	public ArrayList<TheaterDTO> theaterList() {
		return Database.tb_theater;
	}
	
	// 좌석등록
	@Override
	public void insertSeat(SeatDTO seat) {
		Database.tb_seat.add(seat);
	}
	
	// 좌석리스트
	@Override
	public ArrayList<SeatDTO> seatList() {
		return Database.tb_seat;
	}
	
	
	//날짜등록
	@Override
	public void dateRegister(DateDTO date) {
		Database.tb_date.add(date);
	}

	//날짜 리스트
	@Override
	public ArrayList<DateDTO> dateList() {
		return Database.tb_date;
	}

	// 영화순위
	@Override
	public void movieSort(Integer key, Integer rank) {
		
//		for (int i = 0; i < Database.tb_buyList.size(); i++) {
//			BuyListVO buy = Database.tb_buyList.get(i);
//
//			// 확인 System.out.println(key+"  "+buy.getMovieNum());
//
//			int count = 0;
//			if (key == buy.getMovieNum()) {
//				count += +buy.getSeatNum().size(); // 티켓수더하기
//				Database.tb_movie.get(i).setRank(count);
//			} else {
//				break;
//			}
//		}
		 

		for (int i = 0; i < Database.tb_movie.size(); i++) {
			MovieDTO mo = Database.tb_movie.get(i);

			if (key == mo.getMovieNum()) {
				Database.tb_movie.get(i).setRank(rank);
			}
		}

		for (int i = 0; i < Database.tb_movie.size() - 1; i++) {
			for (int j = i + 1; j < Database.tb_movie.size(); j++) {
				if (Database.tb_movie.get(i).getRank() < Database.tb_movie.get(
						j).getRank()) {
					MovieDTO temp = Database.tb_movie.get(i); // 자리를 바꿈
					Database.tb_movie.set(i, Database.tb_movie.get(j));
					Database.tb_movie.set(j, temp);
				}
			}
		}
	}

	// 공지사항
	@Override
	public ArrayList<NoticeDTO> noticeView() {
		return Database.tb_notice;
	}

	// 공지사항 수정
	@Override
	public ArrayList<NoticeDTO> noticeChange() {
		return Database.tb_notice;
	}

	// 결제내역 저장
	@Override
	public void insertPay(BuyListDTO buy) {
		Database.tb_buyList.add(buy);
	}

	// 구매내역
	@Override
	public ArrayList<BuyListDTO> buyList() {
		return Database.tb_buyList;
	}

	//예매취소
	@Override
	public void movieDrop(String key, int cal) {
		/*for (int i = 0; i < Database.tb_user.size(); i++) {
			UserVO user = Database.tb_user.get(cal);

			if (key == user.getId()) {
				Database.tb_user.remove(i);
			}
		}
	}*/}

}