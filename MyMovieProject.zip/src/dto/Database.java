package dto;

import java.util.ArrayList;

//데이터베이스
public class Database {
	//회원테이블
	public static ArrayList<UserDTO> tb_user = new ArrayList<UserDTO>();
	
	//공지사항
	public static ArrayList<NoticeDTO> tb_notice = new ArrayList<NoticeDTO>();
	
	//영화테이블
	public static ArrayList<MovieDTO> tb_movie = new ArrayList<MovieDTO>();
	
	//상영관테이블
	public static ArrayList<TheaterDTO> tb_theater = new ArrayList<TheaterDTO>();

	//날짜,시간 테이블
	public static ArrayList<DateDTO> tb_date = new ArrayList<DateDTO>();
	
	//좌석 테이블
	public static ArrayList<SeatDTO> tb_seat = new ArrayList<SeatDTO>();
	
	//구매내역 테이블
	public static ArrayList<BuyListDTO> tb_buyList = new ArrayList<BuyListDTO>();
	
}
