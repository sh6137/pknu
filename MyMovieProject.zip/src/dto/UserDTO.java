package dto;

import java.io.Serializable;

//회원 정보
public class UserDTO implements Serializable{
	private String id; //아이디(주요키)
	private String pw; //비밀번호
	private String name; //이름
	private String phone; //핸드폰번호
	private int mileage; //마일리지

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public int getMileage() {
		return mileage;
	}
	public void setMileage(int mileage) {
		this.mileage = mileage;
	}

}