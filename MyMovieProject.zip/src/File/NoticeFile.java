package File;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import dto.Database;
import dto.NoticeDTO;

public class NoticeFile {
	@SuppressWarnings("unchecked")
	public void NoticeFileIn(String noticeTitle, String noticeContent, String noticeWrite, String noticeDate, int noticeNum) throws IOException {
		NoticeDTO notice = new NoticeDTO();
		notice.setNoticeTitle(noticeTitle);
		notice.setNoticeContent(noticeContent);
		notice.setNoticeWrite(noticeWrite);
		notice.setNoticeDate(noticeDate);
		notice.setNoticeNum(noticeNum);
		Database.tb_notice.add(notice);

		File f = new File("Notice.txt");

		ArrayList<NoticeDTO> temp = new ArrayList<NoticeDTO>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
			temp = (ArrayList<NoticeDTO>) ois.readObject();
			temp.add(notice);
			ois.close();
		} catch (EOFException e) {
			FileOutputStream fos = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			temp.add(notice);

			oos.writeObject(temp);
			oos.flush();
			oos.close();
			return;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		FileOutputStream fos = new FileOutputStream(f);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
//		for (UserDTO t : temp) {
//			System.out.println("t  : " + t);
//		}

		oos.writeObject(temp);
		oos.flush();
		oos.close();
	}

	@SuppressWarnings("unchecked")
	public ArrayList<NoticeDTO> NoticeFileOut() throws IOException {
		File f = new File("Notice.txt");
		ArrayList<NoticeDTO> list = new ArrayList<NoticeDTO>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));

			list = (ArrayList<NoticeDTO>) ois.readObject();

			ois.close();

		} catch (EOFException e) {

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return list;
	}
}