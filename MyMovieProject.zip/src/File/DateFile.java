package File;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import dto.Database;
import dto.DateDTO;
import dto.TheaterDTO;

public class DateFile {
	@SuppressWarnings("unchecked")
	public void DateFileIn(int daydate,int movieNum,int theaterNum) throws IOException {
		DateDTO date = new DateDTO();
		date.setDate(daydate);
		date.setMovieNum(movieNum);
		date.setTheaterNum(theaterNum);

		Database.tb_date.add(date);

		File f = new File("Date.txt");

		ArrayList<DateDTO> temp = new ArrayList<DateDTO>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
			temp = (ArrayList<DateDTO>) ois.readObject();
			temp.add(date);
			ois.close();
		} catch (EOFException e) {
			FileOutputStream fos = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			temp.add(date);

			oos.writeObject(temp);
			oos.flush();
			oos.close();
			return;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		FileOutputStream fos = new FileOutputStream(f);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
//		for (UserDTO t : temp) {
//			System.out.println("t  : " + t);
//		}

		oos.writeObject(temp);
		oos.flush();
		oos.close();
	}

	@SuppressWarnings("unchecked")
	public ArrayList<DateDTO> DateFileOut() throws IOException {
		File f = new File("Date.txt");
		ArrayList<DateDTO> list = new ArrayList<DateDTO>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));

			list = (ArrayList<DateDTO>) ois.readObject();

			ois.close();

		} catch (EOFException e) {

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return list;
	}
}