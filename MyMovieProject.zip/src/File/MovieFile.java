package File;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import dto.Database;
import dto.MovieDTO;

public class MovieFile {
	@SuppressWarnings("unchecked")
	public void MovieFileIn(String movieName, String movieIntro, int moviePrice) throws IOException {
		MovieDTO movie = new MovieDTO();
		movie.setMovieName(movieName);
		movie.setMovieIntro(movieIntro);
		movie.setMoviePrice(moviePrice);

		Database.tb_movie.add(movie);

		File f = new File("Movie.txt");

		ArrayList<MovieDTO> temp = new ArrayList<MovieDTO>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
			temp = (ArrayList<MovieDTO>) ois.readObject();
			temp.add(movie);
			ois.close();
		} catch (EOFException e) {
			FileOutputStream fos = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			temp.add(movie);

			oos.writeObject(temp);
			oos.flush();
			oos.close();
			return;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		FileOutputStream fos = new FileOutputStream(f);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
//		for (UserDTO t : temp) {
//			System.out.println("t  : " + t);
//		}

		oos.writeObject(temp);
		oos.flush();
		oos.close();
	}

	@SuppressWarnings("unchecked")
	public ArrayList<MovieDTO> MovieFileOut() throws IOException {
		File f = new File("Movie.txt");
		ArrayList<MovieDTO> list = new ArrayList<MovieDTO>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));

			list = (ArrayList<MovieDTO>) ois.readObject();

			ois.close();

		} catch (EOFException e) {

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return list;
	}
}