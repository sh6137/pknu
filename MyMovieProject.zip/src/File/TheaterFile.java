package File;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import dto.Database;
import dto.TheaterDTO;

public class TheaterFile {
	@SuppressWarnings("unchecked")
	public void TheaterFileIn(int theaterNum,String theaterName) throws IOException {
		TheaterDTO theater = new TheaterDTO();
		theater.setTheaterName(theaterName);
		theater.setTheaterNum(theaterNum);
		

		Database.tb_theater.add(theater);

		File f = new File("Theater.txt");

		ArrayList<TheaterDTO> temp = new ArrayList<TheaterDTO>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
			temp = (ArrayList<TheaterDTO>) ois.readObject();
			temp.add(theater);
			ois.close();
		} catch (EOFException e) {
			FileOutputStream fos = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			temp.add(theater);

			oos.writeObject(temp);
			oos.flush();
			oos.close();
			return;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		FileOutputStream fos = new FileOutputStream(f);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
//		for (UserDTO t : temp) {
//			System.out.println("t  : " + t);
//		}

		oos.writeObject(temp);
		oos.flush();
		oos.close();
	}

	@SuppressWarnings("unchecked")
	public ArrayList<TheaterDTO> TheaterFileOut() throws IOException {
		File f = new File("Theater.txt");
		ArrayList<TheaterDTO> list = new ArrayList<TheaterDTO>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));

			list = (ArrayList<TheaterDTO>) ois.readObject();

			ois.close();

		} catch (EOFException e) {

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return list;
	}
}