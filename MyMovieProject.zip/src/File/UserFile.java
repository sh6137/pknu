package File;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import dto.Database;
import dto.UserDTO;

public class UserFile {
	@SuppressWarnings("unchecked")
	public void UserFileIn(String id, String pw, String name, String phone) throws IOException {
		UserDTO user = new UserDTO();
		user.setName(name);
		user.setId(id);
		user.setMileage(0);
		user.setPhone(phone);
		user.setPw(pw);

		Database.tb_user.add(user);

		File f = new File("user.txt");

		ArrayList<UserDTO> temp = new ArrayList<UserDTO>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
			temp = (ArrayList<UserDTO>) ois.readObject();
			temp.add(user);
			ois.close();
		} catch (EOFException e) {
			FileOutputStream fos = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			temp.add(user);

			oos.writeObject(temp);
			oos.flush();
			oos.close();
			return;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		FileOutputStream fos = new FileOutputStream(f);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
//		for (UserDTO t : temp) {
//			System.out.println("t  : " + t);
//		}

		oos.writeObject(temp);
		oos.flush();
		oos.close();
	}

	@SuppressWarnings("unchecked")
	public ArrayList<UserDTO> UserFileOut() throws IOException {
		File f = new File("user.txt");
		ArrayList<UserDTO> list = new ArrayList<UserDTO>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));

			list = (ArrayList<UserDTO>) ois.readObject();

			ois.close();

		} catch (EOFException e) {

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return list;
	}
}
